Want to contribute? Great! Make sure you've read and understood
[CONTRIBUTING.md](https://github.com/cartographer-project/cartographer/blob/master/CONTRIBUTING.md).
